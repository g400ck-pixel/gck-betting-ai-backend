# GCK Override Sports — Backend

This turns the dashboard into a real, always-on system: a scheduled job
generates and grades picks once a day, and a plain static website displays
them. No Claude account needed to view it, works identically on any device
(including phones), and your Odds API key never reaches a browser.

## How it fits together

```
generate_picks.py   -->  runs daily via GitHub Actions  -->  writes data/*.json
index.html          -->  static site, just fetches data/*.json  -->  clients view it
```

- `generate_picks.py` — runs all 12 models via the real Anthropic API (with
  web search), grades pending picks by looking up final scores, and pulls
  MLB odds from The Odds API. All server-side.
- `.github/workflows/daily-picks.yml` — the scheduler. Runs the script once
  a day and commits the updated `data/` files back to the repo.
- `index.html` — the dashboard itself. A static page that reads the JSON
  files with a plain `fetch()`. No API keys, no login, works in any browser.
- `data/` — plain JSON files that hold current state: `picks.json`,
  `odds.json`, `run_log.json`, `last_updated.json`.

## One-time setup

### 1. Get a real Anthropic API key
Go to [console.anthropic.com](https://console.anthropic.com), create an API
key, and add billing. This is separate from your claude.ai subscription —
it's billed per use. Twelve models running daily with web search is a
moderate amount of usage; check current pricing on the console before
relying on it heavily.

### 2. Create a GitHub repository
- Create a new repo (public or private both work — see the note on GitHub
  Pages below).
- Upload every file in this folder, preserving the folder structure
  (`.github/workflows/daily-picks.yml` must stay in that exact path).

### 3. Add your secrets
In the repo: **Settings → Secrets and variables → Actions → New repository secret**
- `ANTHROPIC_API_KEY` — the key from step 1
- `ODDS_API_KEY` — your existing key from the-odds-api.com (optional — MLB
  odds just won't populate without it, everything else still works)

### 4. Turn on GitHub Pages
**Settings → Pages → Source: Deploy from a branch → Branch: main, folder: /(root)**
Your dashboard will be live at `https://<your-username>.github.io/<repo-name>/`
within a few minutes. This works whether the repo is public or private —
Pages sites are public regardless (don't put anything in this repo you
don't want publicly viewable, which is why the API keys live in Secrets,
not in any file).

### 5. Run it once manually to check it works
**Actions tab → Daily Picks Generation → Run workflow** (this is the
`workflow_dispatch` trigger — no need to wait for the schedule). Watch the
log; you should see `OK` lines for each model. If you see `FAIL` lines,
the error message is right there in the log.

After that, it runs automatically every day at the time set in the cron
schedule (`0 12 * * *` = 12:00 UTC — edit that line in
`daily-picks.yml` to change it).

## Changing the schedule

Edit the `cron` line in `.github/workflows/daily-picks.yml`. Cron time is
always UTC. A few examples:
- `0 12 * * *` — 12:00 UTC daily
- `0 8,20 * * *` — twice daily, 8am and 8pm UTC
- `*/30 * * * *` — every 30 minutes (only do this if you're comfortable
  with the added Anthropic API usage/cost — running 12 models this often
  adds up fast)

## What's different from the old artifact version

- **No manual "Run this model" button** — generation is fully automatic
  now, on whatever schedule you set.
- **No manual grading form in the UI** — grading is automatic too. If the
  AI can't confirm a result, the pick just stays "Pending" until the next
  run tries again.
- **No "Import odds" paste box** — odds are fetched automatically by the
  script now that the key lives safely server-side.
- **Read-only frontend** — the website only displays what the backend
  generated. To correct something, edit `data/picks.json` directly in the
  repo (or open an issue for yourself and fix it by hand) — there's no
  write-back from the browser, which is what makes it safe to have no
  login system at all.

## Costs to expect

- **Anthropic API usage**: billed per token, scales with how many models
  run and how much web search they each do. Check current pricing at
  anthropic.com/pricing before scaling this up (more sports, more
  frequent runs, etc).
- **The Odds API**: whatever your existing plan covers — usage is roughly
  2-4 credits per MLB game per day.
- **GitHub Actions**: free tier includes 2,000 minutes/month for private
  repos, and is unlimited for public repos. A daily run of this script
  takes a few minutes, so you're very unlikely to hit any limit.
- **GitHub Pages**: free, no limits relevant to this use case.
