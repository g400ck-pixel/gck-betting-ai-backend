"""
generate_picks.py
==================
Backend for the GCK Override Sports dashboard. Runs once per scheduled
invocation (see .github/workflows/daily-picks.yml):

  1. Runs every model that hasn't been generated yet today, using the real
     Anthropic API with web search, and appends any matching picks to
     data/picks.json.
  2. Grades any pending pick whose game date has passed, by asking the
     model to look up the confirmed final result.
  3. Refreshes MLB odds from The Odds API (if ODDS_API_KEY is set) into
     data/odds.json.

All state lives in the data/ folder as plain JSON files, which this script
reads, updates, and rewrites. The GitHub Actions workflow commits those
files back to the repo, and the static frontend (index.html) just reads
them with a plain fetch() -- no API keys ever reach the browser.

Required environment variables:
  ANTHROPIC_API_KEY   - from console.anthropic.com (required)
  ODDS_API_KEY        - from the-odds-api.com (optional; MLB odds only)
"""

import os
import re
import sys
import time
import json
from datetime import date, datetime, timezone

import requests

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
ODDS_API_KEY = os.environ.get("ODDS_API_KEY")
MODEL_NAME = "claude-sonnet-5"
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

ODDS_BASE = "https://api.the-odds-api.com/v4"
ODDS_SPORT = "baseball_mlb"
BOOK_PREFERENCE = ["draftkings", "fanduel", "betmgm", "caesars"]


# ---------------------------------------------------------------------------
# Model definitions -- identical set to the dashboard's frontend copy.
# Keep these two in sync if you ever edit one.
# ---------------------------------------------------------------------------
MODELS = [
    {
        "id": "expert_478", "sport": "MLB", "label": "No. 478", "name": "Pitching Quality Divergence",
        "market": "F5 Spread — Away +1.5", "reportedWinRate": 0.805, "reportedRecord": "33-8", "sampleSize": 41,
        "resultEntryMode": "score",
        "thesis": "Isolates games with an extreme structural quality gap between the two starting pitchers inside the First 5 window. The away starter is elite at limiting hard contact his second time through the order, while the home starter completely breaks down by his third time through — a pitcher-fatigue mismatch sportsbooks tend to miss while pricing overall team strength and home field advantage.",
        "filterText": "Away starter's TTOP2 (2nd time through the order) xwOBA-against is .295 or lower, AND home starter's TTOP3 (3rd time through the order) xwOBA-against is .340 or higher.",
    },
    {
        "id": "expert_475", "sport": "MLB", "label": "No. 475", "name": "F5 Pure Pitching Divergence",
        "market": "F5 Spread — Away +1.5", "reportedWinRate": 0.786, "reportedRecord": "11-3", "sampleSize": 14,
        "resultEntryMode": "score",
        "thesis": "A head-to-head contact-suppression mismatch during the middle innings of the First 5 window. Compares both starters at the exact same time-through-the-order window (2nd time through), rather than different phases like the model above.",
        "filterText": "Away starter's TTOP2 xwOBA-against is .295 or lower, AND home starter's TTOP2 xwOBA-against is .340 or higher (same time-through-order window for both).",
    },
    {
        "id": "expert_457", "sport": "MLB", "label": "No. 457", "name": "Starting Pitcher Dual-Leaking",
        "market": "F5 Spread — Away +1.5", "reportedWinRate": 0.761, "reportedRecord": "83-26", "sampleSize": 109,
        "resultEntryMode": "score",
        "thesis": "A high-volume model built on extreme, multi-dimensional starting pitcher decay. The home starter is failing in two independent ways at once over his last 5 starts — leaking baserunners (WHIP) and leaking runs (ERA) — with no requirement on the away starter at all.",
        "filterText": "Home starter's WHIP over the last 5 starts is 1.30 or higher, AND home starter's ERA over the last 5 starts is 4.00 or higher.",
    },
    {
        "id": "expert_461", "sport": "MLB", "label": "No. 461", "name": "Single-Gate Leaking Starter — WHIP",
        "market": "F5 Spread — Away +1.5", "reportedWinRate": 0.741, "reportedRecord": "103-36", "sampleSize": 139,
        "resultEntryMode": "score",
        "thesis": "A high-volume, single-gate counterpart to the dual-leaking model. Isolates games where the home starter alone is leaking baserunners at an elevated rate over his last 5 starts, catching pitchers on a mechanical or velocity slump before the market adjusts.",
        "filterText": "Home starter's WHIP over the last 5 starts is 1.30 or higher (no other gate required).",
    },
    {
        "id": "expert_455", "sport": "MLB", "label": "No. 455", "name": "Single-Gate Leaking Starter — ERA",
        "market": "F5 Spread — Away +1.5", "reportedWinRate": 0.733, "reportedRecord": "99-36", "sampleSize": 135,
        "resultEntryMode": "score",
        "thesis": "A high-volume, single-gate model isolating home starters with an elevated ERA over their last 5 starts, independent of any other pitcher's form.",
        "filterText": "Home starter's ERA over the last 5 starts is 4.00 or higher (no other gate required).",
    },
    {
        "id": "expert_500", "sport": "MLB", "label": "No. 500", "name": "Dominant Arm vs. Cold Bats",
        "market": "Runline — Away +1.5", "reportedWinRate": 0.750, "reportedRecord": "6-2 (2026) · 44-11 (2024)", "sampleSize": 8,
        "resultEntryMode": "score",
        "thesis": "Isolates full-game road spread covers by combining immediate first-inning starting pitcher dominance with a freezing cold home offense. The away starter's swing-and-miss stuff suppresses early scoring, and the cold lineup can't generate the pressure to clear the runline cushion.",
        "filterText": "Away starter's first-inning strikeout rate is 30% or higher, AND home lineup's 14-day EMA wOBA is .310 or lower.",
    },
    {
        "id": "nfl_situational", "sport": "NFL", "label": "NFL", "name": "Situational Edge Finder",
        "market": "Spread / Total", "reportedWinRate": None, "reportedRecord": None, "sampleSize": None,
        "resultEntryMode": "winloss",
        "thesis": "Looks for situational edges the market tends to underprice: rest and travel differential, short weeks, revenge or letdown spots, weather effects on the total, and key injuries breaking late in the week.",
        "filterText": None,
    },
    {
        "id": "cfl_situational", "sport": "CFL", "label": "CFL", "name": "Situational Edge Finder",
        "market": "Spread / Total", "reportedWinRate": None, "reportedRecord": None, "sampleSize": None,
        "resultEntryMode": "winloss",
        "thesis": "The same kind of situational edge-finding as the NFL model, adapted to the CFL's shorter week, three-down game, and thinner roster depth — rest, cross-country travel, and quarterback-status changes late in the week.",
        "filterText": None,
    },
    {
        "id": "wnba_pace", "sport": "WNBA", "label": "WNBA", "name": "Pace & Fatigue Mismatch",
        "market": "Spread / Total", "reportedWinRate": None, "reportedRecord": None, "sampleSize": None,
        "resultEntryMode": "winloss",
        "thesis": "Looks for pace mismatches and fatigue spots: a fast-pace team against a slow-pace team, or a team on the second half of a back-to-back / short rest facing a fully rested opponent.",
        "filterText": None,
    },
    {
        "id": "nba_pace", "sport": "NBA", "label": "NBA", "name": "Pace & Rest Mismatch",
        "market": "Spread / Total", "reportedWinRate": None, "reportedRecord": None, "sampleSize": None,
        "resultEntryMode": "winloss",
        "thesis": "Looks for the well-known rest-advantage angle: a team on zero days rest (especially the second night of a back-to-back) against an opponent with two or more days off, plus pace mismatches that push totals.",
        "filterText": None,
    },
    {
        "id": "nhl_goalie", "sport": "NHL", "label": "NHL", "name": "Starting Goalie Divergence",
        "market": "Puck line / Total", "reportedWinRate": None, "reportedRecord": None, "sampleSize": None,
        "resultEntryMode": "winloss",
        "thesis": "The hockey analog to a starting-pitcher model: looks for a confirmed quality gap between the two starting goaltenders' recent save percentage and form, especially when one team is starting a backup or a goalie on the second night of a back-to-back.",
        "filterText": None,
    },
    {
        "id": "soccer_form", "sport": "SOCCER", "label": "Soccer", "name": "Form & Fixture Congestion",
        "market": "Match result / Total", "reportedWinRate": None, "reportedRecord": None, "sampleSize": None,
        "resultEntryMode": "winloss",
        "thesis": "Looks for a form and fixture-congestion mismatch: a team on a genuine unbeaten run against a team dealing with fixture pile-up (midweek European or cup games), key injuries/suspensions, or a long winless stretch.",
        "filterText": None,
    },
]


# ---------------------------------------------------------------------------
# Anthropic API
# ---------------------------------------------------------------------------

def call_claude(messages, tools=None, max_tokens=4000, attempt=1):
    if not ANTHROPIC_API_KEY:
        raise RuntimeError("ANTHROPIC_API_KEY is not set")
    payload = {"model": MODEL_NAME, "max_tokens": max_tokens, "messages": messages}
    if tools:
        payload["tools"] = tools
    try:
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json=payload,
            timeout=120,
        )
    except requests.RequestException as e:
        if attempt < 2:
            time.sleep(2)
            return call_claude(messages, tools, max_tokens, attempt + 1)
        raise RuntimeError(f"network error calling Claude: {e}")

    if resp.status_code >= 500 and attempt < 2:
        time.sleep(2)
        return call_claude(messages, tools, max_tokens, attempt + 1)
    if not resp.ok:
        raise RuntimeError(f"HTTP {resp.status_code} from Claude API: {resp.text[:300]}")
    return resp.json()


def extract_text(data):
    return "\n".join(
        b.get("text", "") for b in data.get("content", []) if b.get("type") == "text"
    ).strip()


def parse_json_array(text):
    clean = re.sub(r"```json|```", "", text).strip()
    try:
        parsed = json.loads(clean)
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []


def parse_json_object(text):
    clean = re.sub(r"```json|```", "", text).strip()
    try:
        parsed = json.loads(clean)
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


# ---------------------------------------------------------------------------
# Model runner
# ---------------------------------------------------------------------------

def build_model_prompt(model, today):
    if model["reportedWinRate"] is not None:
        claim_line = (
            f"Reported historical win rate for this model: "
            f"{model['reportedWinRate'] * 100:.1f}% ({model['reportedRecord']}, {model['sampleSize']} games)."
        )
    else:
        claim_line = "This model has no prior backtested win rate — you are the first pass at finding real games that fit its thesis."

    filter_line = f"Numeric pattern this model looks for: {model['filterText']}" if model["filterText"] else ""

    return f"""Today's date is {today}.

You are running ONE specific betting model for {model['sport']}, independently. Do not consider or mention any other model or sport.

Model: {model['label']} — {model['name']}
Sport: {model['sport']}
Market: {model['market']}
Thesis: {model['thesis']}
{filter_line}
{claim_line}

Task: Using web search, find today's {model['sport']} games or matches. Check each one against this model's thesis above. Only say a game matches if you find real, specific information supporting it, and note where each piece of information came from. If you can't find real support for a required condition, do not estimate or guess — that game does not match.

For every match, state exactly which side or line you are picking for this market (e.g. "Kansas City Chiefs -3.5", "Under 47.5", "Boston Bruins moneyline"). Be specific enough that someone could grade this pick against a final score without guessing what was meant.

Also find 1-3 short, genuinely relevant trends for each matching game (an against-the-spread trend, a head-to-head trend, a home/away split, or a recent form trend), each with a brief source note. Skip a trend rather than inventing one if you can't find something real.

Respond with ONLY a JSON array, no markdown code fences and no text before or after it. Each element:
{{
  "away_team": "team name or abbreviation",
  "home_team": "team name or abbreviation",
  "date": "YYYY-MM-DD",
  "pick": "exact side/line being picked",
  "matched_stats": {{"detail name": "value — short source note"}},
  "trends": [{{"trend": "short trend description", "source": "short source note"}}],
  "writeup": "3-4 sentences explaining in plain language why this specific game matches the pattern, referencing real information and where it came from. Do not tell the reader to bet or not bet."
}}
If nothing matches today for this model, respond with exactly: []"""


def build_slate_prompt(sport, today):
    return f"""Today's date is {today}.

Task: Using web search, find every {sport} game or match happening today. For EACH game (not just ones matching any particular betting angle), write a short general analysis -- storylines, form, injuries, what makes it interesting -- independent of any specific betting model.

Respond with ONLY a JSON array, no markdown code fences and no text before or after it. Each element:
{{
  "away_team": "team name or abbreviation",
  "home_team": "team name or abbreviation",
  "date": "YYYY-MM-DD",
  "writeup": "3-4 sentences of general game analysis: form, injuries, storylines, what to watch. Do not tell the reader to bet or not bet, and do not reference any specific betting model or line."
}}
If there are no {sport} games today, respond with exactly: []"""


def run_slate_writeups(sport, today):
    prompt = build_slate_prompt(sport, today)
    data = call_claude(
        messages=[{"role": "user", "content": prompt}],
        tools=[{"type": "web_search_20250305", "name": "web_search"}],
    )
    games = parse_json_array(extract_text(data))

    entries = []
    for item in games:
        away = item.get("away_team")
        home = item.get("home_team")
        if not away or not home:
            continue
        entries.append({
            "sport": sport,
            "date": item.get("date") or today,
            "awayTeam": away,
            "homeTeam": home,
            "writeup": item.get("writeup") if isinstance(item.get("writeup"), str) else None,
            "generatedAt": datetime.now(timezone.utc).isoformat(),
        })
    return entries



    prompt = build_model_prompt(model, today)
    data = call_claude(
        messages=[{"role": "user", "content": prompt}],
        tools=[{"type": "web_search_20250305", "name": "web_search"}],
    )
    matches = parse_json_array(extract_text(data))

    picks = []
    for i, item in enumerate(matches):
        away = item.get("away_team")
        home = item.get("home_team")
        if not away or not home:
            continue
        game_date = item.get("date") or today
        game_id = re.sub(r"\s+", "", f"{game_date}_{away}_{home}")
        picks.append({
            "id": f"{game_id}_{model['id']}_{int(time.time())}_{i}",
            "gameId": game_id,
            "date": game_date,
            "sport": model["sport"],
            "awayTeam": away,
            "homeTeam": home,
            "ruleId": model["id"],
            "ruleLabel": model["label"],
            "ruleName": model["name"],
            "market": model["market"],
            "pickSide": item.get("pick"),
            "resultEntryMode": model["resultEntryMode"],
            "confidencePct": (model["reportedWinRate"] * 100) if model["reportedWinRate"] is not None else None,
            "reportedRecord": model["reportedRecord"],
            "sampleSize": model["sampleSize"],
            "stats": item.get("matched_stats") if isinstance(item.get("matched_stats"), dict) else {},
            "trends": item.get("trends") if isinstance(item.get("trends"), list) else [],
            "writeup": item.get("writeup") if isinstance(item.get("writeup"), str) else None,
            "writeupStatus": "ready" if isinstance(item.get("writeup"), str) and item.get("writeup").strip() else "error",
            "result": "pending",
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "source": "auto",
        })
    return picks


# ---------------------------------------------------------------------------
# Grading
# ---------------------------------------------------------------------------

def grade_pick(pick):
    prompt = f"""Using web search, find the confirmed final result of this game and determine whether the specified pick won or lost. Do not guess if you can't find a confirmed result.

Sport: {pick['sport']}
Game: {pick['awayTeam']} @ {pick['homeTeam']} on {pick['date']}
Market: {pick['market']}
Pick being graded: {pick.get('pickSide') or '(side not recorded — use your best judgment based on the market description)'}

If the market is a First-5-innings market, find the score through 5 innings specifically, not the final game score. Determine whether the stated pick actually won or lost based on the real result.

Respond with ONLY a JSON object, no markdown fences: {{"result": "win", "loss", or "unknown" if you can't confirm, "final_score": "short final score description", "source": "short source note"}}"""

    data = call_claude(
        messages=[{"role": "user", "content": prompt}],
        tools=[{"type": "web_search_20250305", "name": "web_search"}],
        max_tokens=600,
    )
    parsed = parse_json_object(extract_text(data))
    if parsed and parsed.get("result") in ("win", "loss"):
        pick["result"] = parsed["result"]
        pick["finalScore"] = parsed.get("final_score")
        pick["gradeSource"] = parsed.get("source")
    # 'unknown' or unparseable -> leave pending, retried on the next run.


# ---------------------------------------------------------------------------
# MLB odds (The Odds API) -- server-side now, key never reaches a browser
# ---------------------------------------------------------------------------

def pick_primary_bookmaker(bookmakers):
    by_key = {b["key"]: b for b in bookmakers}
    for pref in BOOK_PREFERENCE:
        if pref in by_key:
            return by_key[pref]
    return bookmakers[0] if bookmakers else None


def extract_market(bookmaker, market_key):
    if not bookmaker:
        return None
    for market in bookmaker.get("markets", []):
        if market["key"] == market_key:
            return market.get("outcomes")
    return None


def fetch_mlb_odds():
    if not ODDS_API_KEY:
        print("ODDS_API_KEY not set -- skipping odds fetch.")
        return []

    resp = requests.get(
        f"{ODDS_BASE}/sports/baseball_mlb/odds",
        params={"apiKey": ODDS_API_KEY, "regions": "us", "markets": "h2h,spreads,totals", "oddsFormat": "american"},
        timeout=30,
    )
    if not resp.ok:
        print(f"Odds fetch failed: {resp.status_code} {resp.text[:200]}", file=sys.stderr)
        return []
    slate = resp.json()

    results = []
    for event in slate:
        away, home = event["away_team"], event["home_team"]
        primary_full = pick_primary_bookmaker(event.get("bookmakers", []))
        full_game = {
            "book": primary_full["key"] if primary_full else None,
            "h2h": extract_market(primary_full, "h2h"),
            "spreads": extract_market(primary_full, "spreads"),
            "totals": extract_market(primary_full, "totals"),
        }

        first_5_innings = None
        for markets in ("h2h_1st_5_innings,spreads_1st_5_innings,totals_1st_5_innings",
                        "h2h_1st_5_innings,totals_1st_5_innings", "h2h_1st_5_innings"):
            f5_resp = requests.get(
                f"{ODDS_BASE}/sports/baseball_mlb/events/{event['id']}/odds",
                params={"apiKey": ODDS_API_KEY, "regions": "us", "markets": markets, "oddsFormat": "american"},
                timeout=30,
            )
            if f5_resp.ok:
                f5_data = f5_resp.json()
                if f5_data.get("bookmakers"):
                    primary_f5 = pick_primary_bookmaker(f5_data["bookmakers"])
                    first_5_innings = {
                        "book": primary_f5["key"] if primary_f5 else None,
                        "h2h": extract_market(primary_f5, "h2h_1st_5_innings"),
                        "spreads": extract_market(primary_f5, "spreads_1st_5_innings"),
                        "totals": extract_market(primary_f5, "totals_1st_5_innings"),
                    }
                break
            if f5_resp.status_code != 422:
                break
        time.sleep(0.3)

        results.append({
            "away_team": away, "home_team": home,
            "commence_time": event.get("commence_time"),
            "full_game": full_game, "first_5_innings": first_5_innings,
        })
    return results


# ---------------------------------------------------------------------------
# Storage helpers (flat JSON files, committed to the repo by the workflow)
# ---------------------------------------------------------------------------

def load_json(name, default):
    path = os.path.join(DATA_DIR, name)
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return default


def save_json(name, obj):
    os.makedirs(DATA_DIR, exist_ok=True)
    path = os.path.join(DATA_DIR, name)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    today = date.today().isoformat()
    picks = load_json("picks.json", [])
    run_log = load_json("run_log.json", {})

    print(f"=== Generating picks for {today} ===")
    for model in MODELS:
        if run_log.get(model["id"]) == today:
            print(f"skip  {model['sport']:8s} {model['name']} (already run today)")
            continue
        try:
            new_picks = run_model(model, today)
            picks.extend(new_picks)
            run_log[model["id"]] = today
            print(f"OK    {model['sport']:8s} {model['name']}: {len(new_picks)} pick(s)")
        except Exception as e:
            # Do NOT mark run_log on failure -- next scheduled run retries.
            print(f"FAIL  {model['sport']:8s} {model['name']}: {e}", file=sys.stderr)
        save_json("picks.json", picks)
        save_json("run_log.json", run_log)

    print("=== Grading finished games ===")
    graded_any = False
    for pick in picks:
        if pick["result"] == "pending" and pick["date"] < today:
            try:
                grade_pick(pick)
                graded_any = True
                print(f"graded {pick['awayTeam']} @ {pick['homeTeam']}: {pick['result']}")
            except Exception as e:
                print(f"grade FAIL {pick['id']}: {e}", file=sys.stderr)
    if graded_any:
        save_json("picks.json", picks)

    print("=== Generating all-game writeups per sport ===")
    game_writeups = load_json("game_writeups.json", {})
    writeup_log = load_json("writeup_log.json", {})
    for sport in sorted(set(m["sport"] for m in MODELS)):
        if writeup_log.get(sport) == today:
            print(f"skip  {sport:8s} slate writeups (already run today)")
            continue
        try:
            entries = run_slate_writeups(sport, today)
            # Replace today's entries for this sport rather than appending,
            # so re-running the same day doesn't duplicate.
            existing = [e for e in game_writeups.get(sport, []) if e["date"] != today]
            game_writeups[sport] = existing + entries
            writeup_log[sport] = today
            print(f"OK    {sport:8s} slate writeups: {len(entries)} game(s)")
        except Exception as e:
            print(f"FAIL  {sport:8s} slate writeups: {e}", file=sys.stderr)
        save_json("game_writeups.json", game_writeups)
        save_json("writeup_log.json", writeup_log)

    print("=== Refreshing MLB odds ===")
    try:
        odds = fetch_mlb_odds()
        save_json("odds.json", odds)
        print(f"Saved odds for {len(odds)} game(s).")
    except Exception as e:
        print(f"Odds fetch failed: {e}", file=sys.stderr)

    save_json("last_updated.json", {"utc": datetime.now(timezone.utc).isoformat()})
    print("Done.")


if __name__ == "__main__":
    main()
